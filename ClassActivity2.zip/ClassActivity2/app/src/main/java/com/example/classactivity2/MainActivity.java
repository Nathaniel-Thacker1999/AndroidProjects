package com.example.classactivity2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import android.content.SharedPreferences;

public class MainActivity extends AppCompatActivity implements OnEditorActionListener, OnClickListener {

    private EditText userName;
    private EditText firstNumber;
    private EditText secondNumber;
    private TextView theResult;
    private Button clickButton;

    private int total = 0;
    private int numberOne = 0;
    private int numberTwo = 0;
    private String totalResult = "";

    private SharedPreferences savedValues;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView(R.layout.activity_main);

        userName = (EditText) findViewById(R.id.txtName);
        firstNumber = (EditText) findViewById(R.id.txtNumber1);
        secondNumber = (EditText) findViewById(R.id.txtNumber2);
        clickButton = (Button) findViewById(R.id.btnButton);
        theResult = (TextView) findViewById (R.id.lblResult);

        clickButton.setOnClickListener(this);
    }

    public void calculateResult() {
        String name = userName.getText().toString();
        int number1 = Integer.parseInt(firstNumber.getText().toString());
        int number2 = Integer.parseInt(secondNumber.getText().toString());
        total = number1 + number2;
        totalResult = name + ", the total number is " + Integer.toString(total);
        theResult.setText(totalResult);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnButton:
                calculateResult();
                break;
        }

    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        return false;
    }

}