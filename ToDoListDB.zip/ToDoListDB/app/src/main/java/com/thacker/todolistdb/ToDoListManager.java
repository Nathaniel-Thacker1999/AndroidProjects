package com.thacker.todolistdb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class ToDoListManager {
    static final String DB_ToDoList = "DB_ToDoList.db";   //DB name
    static final String TABLE_ToDoList = "TABLE_ToDoList"; //Table name
    static final int DB_VERSION = 1;         //DB version

    Context myContext = null;
    private static ToDoListManager myDBManager = null;
    private SQLiteDatabase mydatabase = null;

    public static ToDoListManager getInstance(Context context)
    {
        if(myDBManager == null)
        {
            myDBManager = new ToDoListManager(context);
        }
        return myDBManager;
    }
    private ToDoListManager(Context context) //constructor
    {
        myContext = context;
        mydatabase = context.openOrCreateDatabase(DB_ToDoList, context.MODE_PRIVATE,null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_ToDoList +  "(" + "_id INTEGER PRIMARY KEY AUTOINCREMENT," + "ToDo TEXT);");
    }
    public long insert(ContentValues addRowValue)
    {
        return mydatabase.insert(TABLE_ToDoList, null, addRowValue);
    }
    public int delete(String whereClause, String[] whereArgs)
    {
        return mydatabase.delete(TABLE_ToDoList, whereClause, whereArgs);
    }
    public Cursor query(String[] colums, String selection, String[] selectionArgs, String groupBy, String having, String orderby)
    {
        return mydatabase.query(TABLE_ToDoList, colums, selection, selectionArgs, groupBy, having, orderby);
    }
}
