package com.thacker.todolistdb;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    ListView lvToDo;
    ArrayAdapter<String> toDoAdapter;
    ArrayList<String> thingsToDo=new ArrayList<>();;
    TextView TextViewID;
    EditText editTextToDo;
    ToDoListManager databaseManager;
    ToDoItem myItem = new ToDoItem();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databaseManager = ToDoListManager.getInstance(this);
        TextViewID = (TextView)findViewById(R.id.id);
        editTextToDo = (EditText)findViewById(R.id.ToDo);
        lvToDo=(ListView) findViewById(R.id.lvToDo);
        toDoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, thingsToDo);
        lvToDo.setAdapter(toDoAdapter);
        getToDoListData();
        lvToDo.setOnItemClickListener(this);
    }
    public void clickHandler(View view)
    {
        switch (view.getId()) {
            case R.id.btn_resetDisplay:
                getToDoListData();
                resetDisplay();
                break;
            case R.id.btn_add:
                if (editTextToDo.getText().toString().isEmpty()) {
                    Toast.makeText(this, "Enter ToDo first.", Toast.LENGTH_SHORT).show();
                }
                else{
                    ContentValues addRowValue = new ContentValues();
                    addRowValue.put("ToDo", editTextToDo.getText().toString());
                    databaseManager.insert(addRowValue);
                    getToDoListData();
                }
                break;

            case R.id.btn_update:
                if ((TextViewID.getText().toString().isEmpty())||(editTextToDo.getText().toString().isEmpty())) {
                    Toast.makeText(this, "Select Item and Enter ToDo first.", Toast.LENGTH_SHORT).show();
                }
                else{
                    ContentValues updateRowValue = new ContentValues();
                    updateRowValue.put("ToDo", editTextToDo.getText().toString());
                    databaseManager.update(updateRowValue, "_id =" + TextViewID.getText().toString() , null);
                    getToDoListData();
                    Toast.makeText(this, "Updated!!!", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.btn_delete:
                if (TextViewID.getText().toString().isEmpty()) {
                    Toast.makeText(this, "Select Item first.", Toast.LENGTH_SHORT).show();
                }
                else{
                    databaseManager.delete("_id =" + TextViewID.getText().toString(), null);
                    getToDoListData();
                    resetDisplay();
                    Toast.makeText(this, "Deleted!!!", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
    public void resetDisplay()
    {
        TextViewID.setText("");
        editTextToDo.setText("");
    }
    public void getToDoListData()
    {
        String[] columns = new String[] {"_id", "ToDo"};
        Cursor cursor = databaseManager.query(columns, null, null,null,null,null);
        int position =0;
        thingsToDo.clear();

        if(cursor != null)
        {
            while (cursor.moveToNext())
            {
                position ++;
                String position_ID   =   Integer.toString(position);
                String DB_id         =   Integer.toString(cursor.getInt(0));
                String DB_ToDo       =   cursor.getString(1);
                String DB_Add        =   position_ID  + ". " + DB_id  + ". " +DB_ToDo;
                thingsToDo.add(DB_Add);
            }
        }
        lvToDo.setAdapter(toDoAdapter);
    }
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String myClikedValue = parent.getItemAtPosition(position).toString();
        String[] id_ToDo = myClikedValue.split(". ");
        myItem.setNumber(Integer.parseInt(id_ToDo[0]));
        myItem.setId(Integer.parseInt(id_ToDo[1]));
        myItem.setToDoItem(id_ToDo[2]);
        TextViewID.setText(myItem.getStringId());
        editTextToDo.setText(myItem.getToDoItem());
        Toast.makeText(this, "Clicked " +  myItem.getAllString(), Toast.LENGTH_SHORT).show();
    }
}
