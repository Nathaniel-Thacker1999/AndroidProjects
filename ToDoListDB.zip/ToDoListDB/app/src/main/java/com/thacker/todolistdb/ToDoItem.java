package com.thacker.todolistdb;

public class ToDoItem {
    private int id;
    private int number;
    private String toDoItem;

    public ToDoItem()
    {
        this.id =0;
        this.number=0;
        this.toDoItem ="Nothing";
    }
    public ToDoItem(int id, int number, String toDoItem){
        this.id =id;
        this.number=number;
        this.toDoItem =toDoItem;
    }
    public int getNumber(){
        return this.number;
    }
    public String getStringNumber(){
        return Integer.toString(this.number);
    }
    public void setNumber(int newNumber){
        this.number = newNumber;
    }
    public int getId(){
        return this.id;
    }
    public String getStringId(){
        return Integer.toString(this.id);
    }
    public void setId(int newId){
        this.id = newId;
    }
    public String getToDoItem(){
        return this.toDoItem;
    }
    public void setToDoItem(String newItem){
        this.toDoItem = newItem;
    }
    public String getAllString(){
        return (Integer.toString(this.number) + ". "+ Integer.toString(this.id) + ". " + this.toDoItem);
    }
    public String getIdToDoString(){
        return (Integer.toString(this.number) + ". "+ Integer.toString(this.id) + ". " + this.toDoItem);
    }
}
